export default function Venues() {
  return <main style={{padding: 20, fontFamily: 'system-ui'}}>Venues route OK ✅</main>;
}
